import { createElement, useState, useEffect } from "react";

import { View, TextStyle, ViewStyle, TextInput, FlatList, Text, TouchableOpacity, Modal, StyleSheet, TouchableWithoutFeedback } from "react-native";

import { Style } from "@mendix/pluggable-widgets-tools";

import { SearchableDropDownProps } from "../typings/SearchableDropDownProps";

import { ObjectItem } from "mendix";


// interface DisplayItem {
//     id: string;
//     displayValue: string;
//     object: ObjectItem;
// }

export interface CustomStyle extends Style {
    container: ViewStyle;
    label: TextStyle;
}



export function SearchableDropDown(props: SearchableDropDownProps<ViewStyle>) {
    const [searchText, setSearchText] = useState("");
    const [selectedText, setSelectedText] = useState("");
    const [isDropdownVisible, setIsDropdownVisible] = useState(false);




    useEffect(() => {
        if (props.ValuetoSet?.value && props.displayAttribute) {
            const value = props.displayAttribute.get(props.ValuetoSet.value)?.value;
            if (value) setSelectedText(value);
        }
    }, [props.ValuetoSet?.value]);


    const filteredOptions = props.objectsDatasource?.items?.filter(item => {
        const label = props.displayAttribute.get(item)?.value ?? "";
        return label.toLowerCase().includes(searchText.toLowerCase());
    }) ?? [];

    const closeDropdown = () => setIsDropdownVisible(false);

    const handleSelect = (item: ObjectItem) => {
        try {
            if (props.ValuetoSet?.setValue) {
                props.ValuetoSet.setValue(item);
                props.Onclick?.execute();
                setSelectedText(props.displayAttribute.get(item)?.value ?? "Unnamed")
            }
            // const selected = props.displayAttribute.get(item)?.value ?? "Unnamed";
            setSearchText("");
            setIsDropdownVisible(false);
            if (!item) {

            }
        } catch (error) {

        }
    };
    const toggleDropdown = (): void => {


        setIsDropdownVisible(prev => !prev);
    };



    const handleClear = () => {
        setSearchText("");
        props.ValuetoSet?.setValue(undefined);
        setSelectedText("");
    };

    const triggerAction = () => {
        props.change?.execute();

    }

    // ✅ Return simple text input if selectMode is "runAction"
    if (props.RenType.valueOf() == "OAC") {
        return (
            <View style={styles.container} >
                <Text style={styles.lbl}>{props.Labl.value}</Text>
                <View style={styles.input}>
                    <Text style={styles.inputText}>
                        {selectedText || "Select..."}
                    </Text>
                    <View style={styles.icons}>
                        <TouchableOpacity onPress={triggerAction}>
                            <Text style={styles.clearText}>🔍</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        );
    }

    return (

        <View style={styles.container} >
            <Text style={styles.lbl}>{props.Labl.value}</Text>
            <TouchableOpacity onPress={toggleDropdown}>
                <View style={styles.input}>
                    <Text style={styles.inputText}>
                        {selectedText || "Select..."}
                    </Text>
                    <View style={styles.icons}>
                        {/* {searchText.length > 0 && ( */}
                        <TouchableOpacity onPress={handleClear}>
                            <Text style={styles.clearText}>✖️</Text>
                        </TouchableOpacity>
                        {/* // )} */}
                        <Text style={styles.chevron}>{isDropdownVisible ? "▲" : "▼"}</Text>
                    </View>
                </View>
            </TouchableOpacity>

            {/* {isDropdownVisible && (
           
                <View style={styles.dropdown}>
                    <TextInput
                        style={styles.searchBox}
                        placeholder="Search..."
                        value={searchText}
                        onChangeText={setSearchText}
                        autoCorrect={false}
                        autoCapitalize="none"
                    />
                    <View style={{ maxHeight: 250 }}>
                        <FlatList
                            data={filteredOptions}
                            keyExtractor={item => item.id}
                            renderItem={({ item }) => {
                                const label = props.displayAttribute.get(item)?.value ?? "Unnamed";
                                return (
                                    <TouchableOpacity
                                        onPress={() => handleSelect(item)}
                                        style={[
                                            styles.item,
                                            props.ValuetoSet?.value?.id === item.id ? styles.selectedItem : null
                                        ]}
                                    >
                                        <Text style={styles.itemText}>{label}</Text>
                                    </TouchableOpacity>
                                );
                            }}
                            ListEmptyComponent={
                                <Text style={styles.noResults}>No results found</Text>
                            }
                            keyboardShouldPersistTaps="handled"
                           showsVerticalScrollIndicator={true}
                        />
                    </View>
                </View>
            )} */}
            <Modal
                visible={isDropdownVisible}
                transparent
                animationType="fade"
                onRequestClose={closeDropdown}
            >

                <TouchableWithoutFeedback onPress={closeDropdown}>
                    <View style={styles.modalBackdrop}>

                        <View style={styles.dropdown}>
                            <TextInput
                                style={styles.searchBox}
                                placeholder="Search..."
                                value={searchText}
                                onChangeText={setSearchText}
                                autoCorrect={false}
                                autoCapitalize="none"
                            />
                            <FlatList
                                data={filteredOptions}
                                keyExtractor={item => item.id}
                                renderItem={({ item }) => {
                                    const label = props.displayAttribute.get(item)?.value ?? "Unnamed";
                                    return (
                                        <TouchableOpacity
                                            onPress={() => handleSelect(item)}
                                            style={[
                                                styles.item,
                                                props.ValuetoSet?.value?.id === item.id ? styles.selectedItem : null
                                            ]}
                                        >
                                            <Text style={styles.itemText}>{label}</Text>
                                        </TouchableOpacity>
                                    );
                                }}
                                ListEmptyComponent={
                                    <Text style={styles.noResults}>No results found</Text>
                                }
                                keyboardShouldPersistTaps="handled"
                                showsVerticalScrollIndicator
                            />
                        </View>

                    </View>

                </TouchableWithoutFeedback>

            </Modal>
        </View>
    );
}
// 
// const styles = StyleSheet.create({
//     container: {
//         minHeight: 60,
//         position: "relative",     // Makes absolute positioning relative to this
//         zIndex: 1
//     },
//     input: {
//         minHeight: 48,
//         minWidth: 48,
//         borderColor: "#cdcdcd",
//         borderWidth: 1,
//         paddingHorizontal: 8,
//         rippleColr: "#f3f3f3",
//         borderRadius: 8,
//         backgroundColor: "#fff",
//         marginBottom: 6,
//         flexDirection: "row",
//         alignItems: "center",
//         justifyContent: "space-between"
//     },
//     inputText: {
//         fontSize: 16,
//         color: "#333",
//         flex: 1
//     },
//     icons: {
//         flexDirection: "row",
//         alignItems: "center",
//         marginLeft: 10,
//         gap: 8
//     },
//     chevron: {
//         fontSize: 16,
//         color: "#666",
//         marginLeft: 6
//     },
//     clearText: {
//         fontSize: 16,
//         color: "black",
//         marginRight: 6
//     },
//     // dropdown: {
//     //     //top: 60,
//     //     position: "absolute",      // This makes it float over others
//     //     backgroundColor: "#fff",
//     //     borderColor: "#ccc",
//     //     borderWidth: 1,
//     //     borderRadius: 5,
//     //     maxHeight: 250,
//     //     zIndex: 999,               // Makes sure it stacks above others
//     //     //elevation: 5,              // For Android shadow
//     //     width: "100%",
//     //     overflow: "hidden",
//     //     //marginTop:20,
//     //     //bottom : 0          // Match parent width
//     // },
//      dropdown: {
//         backgroundColor: "#fff",
//         borderColor: "#ccc",
//         borderWidth: 1,
//         borderRadius: 5,
//         zIndex: 999,
//         width: "100%"
//     },
//     searchBox: {
//         height: 40,
//         borderBottomColor: "#eee",
//         borderBottomWidth: 1,
//         paddingHorizontal: 10
//     },
//     item: {
//         paddingVertical: 10,
//         paddingHorizontal: 12,
//         borderBottomColor: "#eee",
//         borderBottomWidth: 1
//     },
//     selectedItem: {
//         backgroundColor: "#e6f2ff"
//     },
//     itemText: {
//         fontSize: 16
//     },
//     noResults: {
//         padding: 10,
//         fontStyle: "italic",
//         color: "gray"
//     },
//     lbl: {
//         color: "white",
//         marginBottom: 8,
//         fontFamily: "nornmal",
//         textAlign: "left",
//         fontSize: 12

//     }
// });

const styles = StyleSheet.create({
    container: {
        minHeight: 60,
       
    },
    input: {
        minHeight: 48,
        borderColor: "#cdcdcd",
        borderWidth: 1,
        paddingHorizontal: 8,
        borderRadius: 8,
        backgroundColor: "#fff",
        marginBottom: 6,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start"
    },
    inputText: {
        fontSize: 16,
        color: "#333",
        flex: 1
    },
    icons: {
        flexDirection: "row",
        alignItems: "center",
        marginLeft: 10
    },
    chevron: {
        fontSize: 16,
        color: "#666",
        marginLeft: 6
    },
    clearText: {
        fontSize: 16,
        color: "black",
        marginRight: 6
    },
    modalBackdrop: {
        flex: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        paddingHorizontal: 15
    },
    dropdown: {
        backgroundColor: "#fff",
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 5,
        maxHeight: 350,
        width: "100%",
        //elevation: 10,
        shadowColor: "#000",
        shadowOpacity: 0.2,
        marginTop:25,
       
        shadowOffset: { width: 0, height: 4 }
    },
    searchBox: {
        height: 40,
        borderBottomColor: "#eee",
        borderBottomWidth: 1,
        paddingHorizontal: 5,
        marginBottom: 10
    },
    item: {
        paddingVertical: 10,
        borderBottomColor: "#eee",
        borderBottomWidth: 1,
        //paddingHorizontal: 14,

    },
    selectedItem: {
        backgroundColor: "#e6f2ff",


    },
    itemText: {
        fontSize: 16,

    },
    noResults: {
        //padding: 10,
        fontStyle: "italic",
        color: "gray"
    },
    lbl: {
        color: "black",
        marginBottom: 8,
        fontFamily: "normal",
        textAlign: "left",
        fontSize: 12
    }

});